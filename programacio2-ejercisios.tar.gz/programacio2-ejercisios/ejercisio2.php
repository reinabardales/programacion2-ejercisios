<?php 


	for ($b=1; $b <=6 ; $b++) { 

			echo "";

		for ($r=1; $r<=6 ; $r++) { 
			
			echo $b.$r."<br>";
			echo "<br>";
			
	}
}

 ?>
